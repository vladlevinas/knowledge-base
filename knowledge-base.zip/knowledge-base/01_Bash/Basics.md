# Basics

```bash
echo "hello" > file.txt
```
