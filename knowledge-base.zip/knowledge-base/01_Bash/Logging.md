# Logging

```bash
echo "hello" > file.txt
```
