# Network Commands

```bash
echo "hello" > file.txt
```
