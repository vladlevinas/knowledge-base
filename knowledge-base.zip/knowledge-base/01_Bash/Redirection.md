# Redirection

```bash
echo "hello" > file.txt
```
