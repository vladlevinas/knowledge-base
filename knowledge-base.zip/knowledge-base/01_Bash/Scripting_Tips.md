# Scripting Tips

```bash
echo "hello" > file.txt
```
