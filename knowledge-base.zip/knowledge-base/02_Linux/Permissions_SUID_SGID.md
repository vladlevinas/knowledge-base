# Permissions SUID SGID

Добавь сюда заметки, сниппеты и ссылки.
