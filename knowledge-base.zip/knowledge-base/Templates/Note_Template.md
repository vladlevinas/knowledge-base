---
title: <Название темы>
tags: [bash, linux, devops]
updated: {{DATE}}
---

# <Название темы>

## 💻 Code
```bash
# пример команды
```
## 🧠 Notes
- ...

## 🔗 Related
- [[01_Bash/Logging]]
- [[03_DevOps/Kubernetes/Basics]]
