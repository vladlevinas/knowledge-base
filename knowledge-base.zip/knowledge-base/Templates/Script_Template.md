# Название скрипта

## 🧠 Описание
Кратко, зачем нужен скрипт.

## 💻 Код
```bash
#!/usr/bin/env bash
echo "Script started at $(date)"
```
## 🔎 Как использовать
1) Сохранить как `script.sh`
2) `chmod +x script.sh`
3) `./script.sh`
